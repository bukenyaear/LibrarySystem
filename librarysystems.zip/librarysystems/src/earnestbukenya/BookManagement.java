package earnestbukenya;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Earnest
 */
public class BookManagement extends JFrame {

    /**
     * Creates new form BookManagement
     */
    
    public BookManagement() {
        
        initComponents();
        tableUpdate();
    }
    
    Connection connection;
    PreparedStatement statement;
    String url;
    ResultSet rs;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        titledPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldBookID = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldTitle = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldAuthor = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldYear = new javax.swing.JTextField();
        jButtonAdd = new javax.swing.JButton();
        jButtonRefresh = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableBookDetails = new javax.swing.JTable();
        jButtonDelete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BOOK MANAGEMENT");

        titledPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Add Book"));
        titledPanel.setOpaque(false);

        jLabel2.setText("Book ID");

        jLabel3.setText("Title");

        jLabel4.setText("Author");

        jLabel5.setText("Year");

        jButtonAdd.setText("ADD");
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });

        jButtonRefresh.setText("REFRESH");
        jButtonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout titledPanelLayout = new javax.swing.GroupLayout(titledPanel);
        titledPanel.setLayout(titledPanelLayout);
        titledPanelLayout.setHorizontalGroup(
            titledPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titledPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(titledPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldBookID)
                    .addComponent(jTextFieldTitle)
                    .addComponent(jTextFieldAuthor)
                    .addComponent(jTextFieldYear)
                    .addGroup(titledPanelLayout.createSequentialGroup()
                        .addGroup(titledPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(titledPanelLayout.createSequentialGroup()
                        .addComponent(jButtonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonRefresh, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)))
                .addGap(89, 89, 89))
        );
        titledPanelLayout.setVerticalGroup(
            titledPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titledPanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldBookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jTextFieldYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(titledPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAdd)
                    .addComponent(jButtonRefresh))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTableBookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Author", "Year"
            }
        ));
        jTableBookDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableBookDetailsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableBookDetails);

        jButtonDelete.setText("DELETE");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(titledPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 459, Short.MAX_VALUE)
                        .addGap(19, 19, 19))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(286, 286, 286)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonDelete))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(titledPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Function To update the Table
    public void tableUpdate(){
        try {
            int c;
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            url = "jdbc:ucanaccess://books.accdb";
            connection = DriverManager.getConnection(url);
            
            statement = connection.prepareStatement("SELECT * FROM BookManagement");
            rs = statement.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel)jTableBookDetails.getModel();
            model.setRowCount(0);
            
            while (rs.next())
            {
                Vector v2 = new Vector();
                for(int i= 1; i<=c; i++)
                {
                    v2.add(rs.getString("bookID"));
                    v2.add(rs.getString("title"));
                    v2.add(rs.getString("author"));
                    v2.add(rs.getString("year"));
                }
                model.addRow(v2);
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)jTableBookDetails.getModel();
        int selectedRowIndex = jTableBookDetails.getSelectedRow();
        
        int id = Integer.parseInt(model.getValueAt(selectedRowIndex, 0).toString());
        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you Sure you want to delete the Record","Warning", JOptionPane.YES_NO_OPTION);
        
    
        if(dialogResult == JOptionPane.YES_NO_OPTION)
        {
            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                url = "jdbc:ucanaccess://books.accdb";
                connection = DriverManager.getConnection(url);
                statement = connection.prepareStatement("DELETE FROM BookManagement WHERE bookID = ? ");
            
                statement.setInt(1, id);
                statement.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted");
               
               
               jTextFieldBookID.setText("");
               jTextFieldTitle.setText("");
               jTextFieldAuthor.setText("");
               jTextFieldYear.setText("");
               
               jTextFieldBookID.requestFocus();
               
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        }
         
                
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    // ActionListener for the "ADD" button
    private void bttnAddActionPerformed() {
        
        DefaultTableModel model = (DefaultTableModel)jTableBookDetails.getModel();
        model.addRow(new Object[]{
            jTextFieldBookID.getText(), 
            jTextFieldTitle.getText(), 
            jTextFieldAuthor.getText(), 
            jTextFieldYear.getText()});
        
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        // TODO add your handling code here:
        
        String  title, author, year;
        title = jTextFieldTitle.getText();
        author = jTextFieldAuthor.getText(); 
        year = jTextFieldYear.getText();
        
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            url = "jdbc:ucanaccess://books.accdb";
            connection = DriverManager.getConnection(url);
            statement = connection.prepareStatement("INSERT INTO BookManagement (title, author, year) VALUES (?,?,?)");
            
               statement.setString(1, title);
               statement.setString(2, author);
               statement.setString(3, year);
               statement.executeUpdate();
               JOptionPane.showMessageDialog(this, "Record Added");
               
               
               jTextFieldBookID.setText("");
               jTextFieldTitle.setText("");
               jTextFieldAuthor.setText("");
               jTextFieldYear.setText("");
               
               jTextFieldBookID.requestFocus();
               //tableUpdate();
        
              
                           
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
            
            JOptionPane.showMessageDialog(this, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BookManagement.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, ex);
        }
        
        //bttnAddActionPerformed();
        

    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jTableBookDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableBookDetailsMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)jTableBookDetails.getModel();
        int selectedRowIndex = jTableBookDetails.getSelectedRow();
        
        jTextFieldBookID.setText(model.getValueAt(selectedRowIndex, 0).toString()); 
        jTextFieldTitle.setText(model.getValueAt(selectedRowIndex, 1).toString()); 
        jTextFieldAuthor.setText(model.getValueAt(selectedRowIndex, 2).toString()); 
        jTextFieldYear.setText(model.getValueAt(selectedRowIndex, 3).toString()); 
    }//GEN-LAST:event_jTableBookDetailsMouseClicked

    private void jButtonRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRefreshActionPerformed
        tableUpdate();
    }//GEN-LAST:event_jButtonRefreshActionPerformed
  
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        SwingUtilities.invokeLater(() -> new BookManagement());
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        /* Create and display the form */
        
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookManagement().setVisible(true);
            }
        });
        
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonRefresh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableBookDetails;
    private javax.swing.JTextField jTextFieldAuthor;
    private javax.swing.JTextField jTextFieldBookID;
    private javax.swing.JTextField jTextFieldTitle;
    private javax.swing.JTextField jTextFieldYear;
    private javax.swing.JPanel titledPanel;
    // End of variables declaration//GEN-END:variables

    
    
}
